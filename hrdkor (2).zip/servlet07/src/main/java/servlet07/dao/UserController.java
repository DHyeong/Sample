package servlet07.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import servlet07.dto.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/")
public class UserController extends HttpServlet{
	
	private UserDao userDao = null;
	
	
	@Override
	public void init(ServletConfig config)throws ServletException{
		userDao = new UserDao();
		
	}
		
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			doHandler(req,resp);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			doHandler(req,resp);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void doHandler(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, ClassNotFoundException, SQLException {
		req.setCharacterEncoding("utf-8");
		String action = req.getServletPath();
		RequestDispatcher dispatcher =  null;

		System.out.println(action);
		
		switch(action) {
		case "/new" :
			dispatcher = req.getRequestDispatcher("user-form.jsp");
			dispatcher.forward(req, resp);
			break;
			
		case "/insert":
			String username = req.getParameter("username");
			String email = req.getParameter("email");
			String passwd = req.getParameter("passwd");
			
			User user = new User();
			user.setUsername(username);
			user.setEmail(email);
			user.setPasswd(passwd);
			
			try {
				userDao.userInsert(user);
			} catch (ClassNotFoundException e) {

				e.printStackTrace();
			} catch (SQLException e) {

				e.printStackTrace();
			}
			
			resp.sendRedirect("list");
			
			break;
			
		default :
			List<User> users = userDao.userList();
			req.setAttribute("users", users);
			
			dispatcher = req.getRequestDispatcher("user-list.jsp");
			dispatcher.forward(req, resp);		
			break;
		}
		
	}
		
}
