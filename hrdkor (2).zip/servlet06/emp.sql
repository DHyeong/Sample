create table emp(
userid varchar2(20),
passwd varchar2(20),
username varchar2(50)
);
